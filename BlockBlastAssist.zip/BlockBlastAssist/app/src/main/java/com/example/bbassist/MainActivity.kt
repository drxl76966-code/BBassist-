package com.example.bbassist

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val tv = TextView(this).apply {
            text = "1. Tekan Mulai, izinkan overlay & rekam layar.\n2. Buka Block Blast.\n3. Tombol Kal: ketuk 4 pojok (papan & area 3 bidak), cukup sekali.\n4. Tombol Auto: langkah terbaik muncul otomatis tiap giliran (Scan = hitung ulang paksa).\n5. Tombol R-/R+: sesuaikan rasio ukuran bidak jika bentuk salah terbaca."
            textSize = 16f; setPadding(48, 96, 48, 48)
        }
        val btn = Button(this).apply { text = "Mulai"; setOnClickListener { start() } }
        setContentView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(tv); addView(btn) })
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 1)
    }

    @Deprecated("simple")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (rc == 1 && res == RESULT_OK && d != null) {
            startForegroundService(Intent(this, AssistService::class.java).putExtra("code", res).putExtra("data", d))
            moveTaskToBack(true)
        }
    }
}
