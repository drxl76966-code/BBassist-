package com.example.bbassist

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val tv = TextView(this).apply {
            text = "1. Tekan Mulai, lalu izinkan overlay dan rekam layar.\n2. Buka Block Blast. Selesai.\n\nLangkah terbaik muncul otomatis di papan (angka 1, 2, 3 = urutan). Begitu Anda keluar dari game, semuanya hilang sendiri.\n\nBerhenti: tombol ✕ di pojok kanan atas saat main, atau tombol Stop di notifikasi."
            textSize = 16f; setPadding(48, 96, 48, 48)
        }
        val btn = Button(this).apply { text = "Mulai"; setOnClickListener { start() } }
        setContentView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(tv); addView(btn) })
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 1)
    }

    @Deprecated("simple")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (rc == 1 && res == RESULT_OK && d != null) {
            startForegroundService(Intent(this, AssistService::class.java).putExtra("code", res).putExtra("data", d))
            moveTaskToBack(true)
        }
    }
}
