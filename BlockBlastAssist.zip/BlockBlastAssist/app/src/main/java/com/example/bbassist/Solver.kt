package com.example.bbassist

class Shape(val rows: List<String>) {
    val h = rows.size
    val w = rows[0].length
    val masks = rows.map { s -> s.foldIndexed(0) { i, a, ch -> if (ch == '#') a or (1 shl i) else a } }
}

class Move(val slot: Int, val shape: Int, val r: Int, val c: Int)

object Solver {
    val shapes = ArrayList<Shape>()
    private val seen = HashSet<String>()

    private fun rot(m: List<String>): List<String> {
        val h = m.size; val w = m[0].length
        return List(w) { r -> String(CharArray(h) { c -> m[h - 1 - c][r] }) }
    }
    private fun one(m: List<String>) { if (seen.add(m.joinToString("/"))) shapes.add(Shape(m)) }
    private fun add(m: List<String>, mirror: Boolean = false) {
        var a = m
        repeat(4) { one(a); if (mirror) one(a.map { it.reversed() }); a = rot(a) }
    }
    init {
        add(listOf("#")); add(listOf("##")); add(listOf("###")); add(listOf("####")); add(listOf("#####"))
        add(listOf("##", "##")); add(listOf("###", "###", "###")); add(listOf("###", "###"))
        add(listOf("#.", "##")); add(listOf("#..", "#..", "###")); add(listOf("#.", "#.", "##"), true)
        add(listOf("###", ".#.")); add(listOf(".##", "##."), true)
    }
    fun indexOf(rows: List<String>) = shapes.indexOfFirst { it.rows == rows }

    private fun put(rows: IntArray, s: Shape, r: Int, c: Int): IntArray? {
        val n = rows.copyOf()
        for (i in 0 until s.h) {
            val m = s.masks[i] shl c
            if ((n[r + i] and m) != 0) return null
            n[r + i] = n[r + i] or m
        }
        return n
    }
    private fun clearLines(n: IntArray): Pair<IntArray, Int> {
        var cm = 255; var cnt = 0; val full = BooleanArray(8)
        for (i in 0..7) { if (n[i] == 255) { full[i] = true; cnt++ }; cm = cm and n[i] }
        cnt += Integer.bitCount(cm)
        if (cnt == 0) return Pair(n, 0)
        return Pair(IntArray(8) { if (full[it]) 0 else (n[it] and cm.inv()) and 255 }, cnt)
    }
    /** One-piece-away bonus: a line that is 4-7 full whose empty cells form a single run. */
    private fun lineB(x: Int): Double {
        val f = Integer.bitCount(x)
        if (f < 4 || f >= 8) return 0.0
        val m = x.inv() and 255
        val low = m and -m
        return if (((m + low) and m) == 0) (f - 3).toDouble() else 0.0
    }
    private fun ev(r: IntArray): Double {
        var f = 0; var p = 0; var b = 0.0
        for (i in 0..7) {
            val x = r[i]
            f += Integer.bitCount(x)
            p += Integer.bitCount((x xor ((x shl 1) or 1)) and 255) + (1 - ((x shr 7) and 1))
            p += Integer.bitCount(x xor (if (i > 0) r[i - 1] else 255))
            b += lineB(x)
        }
        p += Integer.bitCount(r[7] xor 255)
        for (j in 0..7) { var x = 0; for (i in 0..7) x = x or (((r[i] shr j) and 1) shl i); b += lineB(x) }
        return -2.0 * f - 0.9 * p + 1.5 * b
    }

    private const val K = 30
    private class Cand(val score: Double, val moves: List<Move>, val rows: IntArray, val miss: Int)

    /** Fixed random "next deals" used to estimate how safe a resulting board is. */
    private val samples: List<IntArray> by lazy {
        val rnd = java.util.Random(7)
        List(20) { IntArray(3) { rnd.nextInt(shapes.size) } }
    }

    /** True if some order/placement fits all three pieces of the trio (with a node budget). */
    private fun feasible(start: IntArray, trio: IntArray): Boolean {
        var budget = 6000
        fun go(rows: IntArray, mask: Int): Boolean {
            if (mask == 7) return true
            for (k in 0..2) {
                if (((mask shr k) and 1) != 0) continue
                val s = shapes[trio[k]]
                for (r in 0..8 - s.h) for (c in 0..8 - s.w) {
                    if (--budget < 0) return false
                    val n = put(rows, s, r, c) ?: continue
                    if (go(clearLines(n).first, mask or (1 shl k))) return true
                }
            }
            return false
        }
        return go(start, 0)
    }

    /** pcs = (slot, shapeIndex). Returns the best ordered moves. */
    fun solve(start: IntArray, pcs: List<Pair<Int, Int>>): List<Move> {
        val top = ArrayList<Cand>()
        val mv = ArrayList<Move>()
        fun leaf(rows: IntArray, clears: Int, miss: Int) {
            val s = ev(rows) + 30 * clears + 15 * maxOf(0, clears - 1) - 1000 * miss
            if ((top.size < K || s > top[top.size - 1].score) && top.none { it.rows.contentEquals(rows) }) {
                var i = top.size
                while (i > 0 && top[i - 1].score < s) i--
                top.add(i, Cand(s, ArrayList(mv), rows, miss))
                if (top.size > K) top.removeAt(top.size - 1)
            }
        }
        fun dfs(rows: IntArray, rem: List<Pair<Int, Int>>, clears: Int) {
            var any = false
            for (k in rem.indices) {
                if ((0 until k).any { rem[it].second == rem[k].second }) continue
                val s = shapes[rem[k].second]
                for (r in 0..8 - s.h) for (c in 0..8 - s.w) {
                    val n = put(rows, s, r, c) ?: continue
                    any = true
                    val (after, cnt) = clearLines(n)
                    mv.add(Move(rem[k].first, rem[k].second, r, c))
                    val nr = rem.filterIndexed { j, _ -> j != k }
                    if (nr.isEmpty()) leaf(after, clears + cnt, 0) else dfs(after, nr, clears + cnt)
                    mv.removeAt(mv.size - 1)
                }
            }
            if (!any) leaf(rows, clears, rem.size)
        }
        dfs(start, pcs, 0)
        if (top.isEmpty()) return emptyList()
        // Lookahead: how often can the resulting board survive a random next deal?
        var best = top[0]; var bs = Double.NEGATIVE_INFINITY
        for (c in top) {
            val f = if (c.miss > 0) 0.0 else samples.count { feasible(c.rows, it) } / samples.size.toDouble()
            val s = c.score + 60 * f
            if (s > bs) { bs = s; best = c }
        }
        return best.moves
    }
}
