package com.example.bbassist

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as L
import android.widget.Button
import android.widget.LinearLayout
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class AssistService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private val lock = Any()
    private var held: Image? = null
    @Volatile private var last: Bitmap? = null
    @Volatile private var auto = false
    @Volatile private var pendingSig = ""
    @Volatile private var solvedSig = ""
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var overlay: OverlayView
    private lateinit var bar: LinearLayout
    private lateinit var autoBtn: Button
    private lateinit var olp: WindowManager.LayoutParams
    private var proj: MediaProjection? = null

    // Auto mode: every 450 ms re-read the screen; solve once the reading is stable and new.
    private val loop = object : Runnable {
        override fun run() { if (auto) grab()?.let { solveFrom(it, false) }; h.postDelayed(this, 450) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("bb", "Block Blast Assist", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bb").setContentTitle("Block Blast Assist aktif")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        if (i == null || proj != null) return START_NOT_STICKY
        @Suppress("DEPRECATION") val data = i.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        prefs = getSharedPreferences("bb", MODE_PRIVATE)
        wm = getSystemService(WindowManager::class.java)
        val mp = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data)
        mp.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)
        proj = mp
        val b = wm.maximumWindowMetrics.bounds
        val rd = ImageReader.newInstance(b.width(), b.height(), PixelFormat.RGBA_8888, 3)
        mp.createVirtualDisplay("bb", b.width(), b.height(), resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, h)
        // Keep only the newest frame (never drop the final one); convert lazily in grab().
        rd.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            synchronized(lock) { held?.close(); held = img }
        }, h)
        buildUi()
        h.postDelayed(loop, 450)
        return START_NOT_STICKY
    }

    private fun grab(): Bitmap? {
        val img = synchronized(lock) { val x = held; held = null; x } ?: return last
        try {
            val pl = img.planes[0]
            val full = Bitmap.createBitmap(pl.rowStride / pl.pixelStride, img.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(pl.buffer)
            last = if (full.width == img.width) full else Bitmap.createBitmap(full, 0, 0, img.width, img.height)
        } finally { img.close() }
        return last
    }

    private fun buildUi() {
        val fl = L.FLAG_NOT_FOCUSABLE or L.FLAG_LAYOUT_IN_SCREEN or L.FLAG_LAYOUT_NO_LIMITS
        olp = L(-1, -1, L.TYPE_APPLICATION_OVERLAY, fl or L.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
        olp.layoutInDisplayCutoutMode = L.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        overlay = OverlayView(this); overlay.cal = loadCal()
        wm.addView(overlay, olp)
        bar = LinearLayout(this)
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; textSize = 11f; minWidth = 0; minimumWidth = 0; setPadding(20, 0, 20, 0); setOnClickListener { f() }
        }
        autoBtn = btn("Auto") { setAuto(!auto) }
        bar.addView(autoBtn); bar.addView(btn("Scan") { scan() }); bar.addView(btn("Kal") { calibrate() })
        bar.addView(btn("R-") { adj(-0.05f) }); bar.addView(btn("R+") { adj(0.05f) })
        bar.addView(btn("✕") { stopSelf() })
        val bp = L(-2, -2, L.TYPE_APPLICATION_OVERLAY, L.FLAG_NOT_FOCUSABLE or L.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT)
        bp.gravity = Gravity.TOP or Gravity.END; bp.y = 40
        wm.addView(bar, bp)
    }

    private fun setAuto(on: Boolean) {
        auto = on; autoBtn.text = if (on) "Auto ✓" else "Auto"
        if (on) { solvedSig = ""; pendingSig = ""; overlay.showRects = false }
        overlay.text = if (on) "Auto aktif" else ""; overlay.invalidate()
    }

    private fun ratio() = prefs.getFloat("ratio", 0.6f)
    private fun adj(d: Float) {
        prefs.edit().putFloat("ratio", (ratio() + d).coerceIn(0.3f, 1.2f)).apply()
        solvedSig = ""; overlay.text = "Rasio bidak: %.2f".format(ratio()); overlay.invalidate()
    }
    private fun loadCal(): FloatArray? = prefs.getString("cal", null)?.split(",")?.map { it.toFloat() }?.toFloatArray()

    private fun calibrate() {
        setAuto(false)
        olp.flags = olp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        wm.updateViewLayout(overlay, olp)
        overlay.startCal { c ->
            prefs.edit().putString("cal", c.joinToString(",")).apply()
            olp.flags = olp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            wm.updateViewLayout(overlay, olp)
        }
    }

    private fun scan() {
        val b = grab()
        if (b == null) { overlay.text = "Belum ada frame, gerakkan layar sebentar"; overlay.invalidate(); return }
        overlay.text = "Memindai…"; overlay.invalidate()
        solveFrom(b, true)
    }

    /** force = solve now; otherwise only when the reading changed and then stayed identical for one more tick. */
    private fun solveFrom(b: Bitmap, force: Boolean) {
        val c = loadCal()
        if (c == null) { overlay.text = "Kalibrasi dulu (tombol Kal)"; overlay.invalidate(); return }
        overlay.cal = c
        if (!busy.compareAndSet(false, true)) return
        val r = ratio()
        exec.execute {
            try {
                val d = Detector.parse(b, c, r)
                val sig = d.rows.joinToString(",") + "|" + d.pieces.joinToString(",") { it?.shape?.toString() ?: "-" }
                if (!force) {
                    if (sig == solvedSig) return@execute
                    if (sig != pendingSig) {
                        pendingSig = sig
                        h.post { overlay.moves = emptyList(); overlay.invalidate() }
                        return@execute
                    }
                    if (d.pieces.all { it == null }) return@execute
                }
                pendingSig = sig; solvedSig = sig
                val pcs = d.pieces.mapIndexedNotNull { i, p -> p?.let { Pair(i, it.shape) } }
                val mv = Solver.solve(d.rows, pcs)
                val info = d.pieces.joinToString(" ") { p -> p?.let { "${Solver.shapes[it.shape].w}x${Solver.shapes[it.shape].h}" } ?: "?" }
                h.post {
                    overlay.moves = mv; overlay.boxes = d.pieces.map { it?.box }
                    overlay.text = (if (mv.isEmpty()) "Tidak ada langkah. " else "") + "Bidak: $info (rasio %.2f)".format(r)
                    overlay.invalidate()
                }
            } finally { busy.set(false) }
        }
    }

    override fun onDestroy() {
        h.removeCallbacks(loop)
        synchronized(lock) { held?.close(); held = null }
        exec.shutdownNow()
        runCatching { wm.removeView(overlay); wm.removeView(bar) }
        proj?.stop()
        super.onDestroy()
    }
}
