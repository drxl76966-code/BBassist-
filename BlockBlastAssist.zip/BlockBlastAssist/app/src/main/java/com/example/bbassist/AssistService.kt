package com.example.bbassist

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as L
import android.widget.Button
import android.widget.LinearLayout
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class AssistService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private val lock = Any()
    private var held: Image? = null
    @Volatile private var last: Bitmap? = null
    @Volatile private var pendingSig = ""
    @Volatile private var solvedSig = ""
    private var cached: BoardRect? = null   // only touched on the exec thread
    private lateinit var wm: WindowManager
    private lateinit var overlay: OverlayView
    private lateinit var bar: LinearLayout
    private var proj: MediaProjection? = null

    // Every 450 ms: look at the screen. Fully automatic, no buttons needed.
    private val loop = object : Runnable {
        override fun run() { grab()?.let { analyze(it) }; h.postDelayed(this, 450) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("bb", "Block Blast Assist", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, AssistService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "bb").setContentTitle("Block Blast Assist aktif")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop).build())
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        if (i == null || proj != null) return START_NOT_STICKY
        @Suppress("DEPRECATION") val data = i.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        wm = getSystemService(WindowManager::class.java)
        val mp = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data)
        mp.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)
        proj = mp
        val b = wm.maximumWindowMetrics.bounds
        val rd = ImageReader.newInstance(b.width(), b.height(), PixelFormat.RGBA_8888, 3)
        mp.createVirtualDisplay("bb", b.width(), b.height(), resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, h)
        // Keep only the newest frame; convert lazily in grab().
        rd.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            synchronized(lock) { held?.close(); held = img }
        }, h)
        buildUi()
        h.postDelayed(loop, 450)
        return START_NOT_STICKY
    }

    private fun grab(): Bitmap? {
        val img = synchronized(lock) { val x = held; held = null; x } ?: return last
        try {
            val pl = img.planes[0]
            val full = Bitmap.createBitmap(pl.rowStride / pl.pixelStride, img.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(pl.buffer)
            last = if (full.width == img.width) full else Bitmap.createBitmap(full, 0, 0, img.width, img.height)
        } finally { img.close() }
        return last
    }

    private fun buildUi() {
        val fl = L.FLAG_NOT_FOCUSABLE or L.FLAG_LAYOUT_IN_SCREEN or L.FLAG_LAYOUT_NO_LIMITS
        val olp = L(-1, -1, L.TYPE_APPLICATION_OVERLAY, fl or L.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
        olp.layoutInDisplayCutoutMode = L.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        overlay = OverlayView(this)
        wm.addView(overlay, olp)
        bar = LinearLayout(this)
        val x = Button(this).apply { text = "✕"; textSize = 12f; minWidth = 0; minimumWidth = 0; setOnClickListener { stopSelf() } }
        bar.addView(x)
        bar.visibility = View.GONE
        val bp = L(-2, -2, L.TYPE_APPLICATION_OVERLAY, L.FLAG_NOT_FOCUSABLE or L.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT)
        bp.gravity = Gravity.TOP or Gravity.END; bp.y = 40
        wm.addView(bar, bp)
    }

    /** Game on screen -> show the stop button and let the overlay draw. Game gone -> hide everything. */
    private fun showGame(r: BoardRect?) {
        if (r == null) {
            overlay.board = null; overlay.moves = emptyList(); overlay.text = ""
            bar.visibility = View.GONE
        } else {
            overlay.board = floatArrayOf(r.fx0, r.fy0, r.fx1, r.fy1)
            bar.visibility = View.VISIBLE
        }
        overlay.invalidate()
    }

    private fun analyze(b: Bitmap) {
        if (!busy.compareAndSet(false, true)) return
        exec.execute {
            try {
                var found = cached
                if (found == null || !Detector.looksLikeBoard(b, found)) {
                    found = Detector.findBoard(b)
                    if (found != null && !Detector.looksLikeBoard(b, found)) found = null
                    cached = found
                }
                val rect = found
                if (rect == null) {
                    pendingSig = ""; solvedSig = ""
                    h.post { showGame(null) }
                    return@execute
                }
                val d = Detector.parse(b, rect)
                h.post { showGame(rect) }
                val sig = d.rows.joinToString(",") + "|" + d.pieces.joinToString(",") { it?.shape?.toString() ?: "-" }
                if (sig == solvedSig) return@execute
                if (sig != pendingSig) {   // reading changed: wait one more tick until it is stable
                    pendingSig = sig
                    h.post { overlay.moves = emptyList(); overlay.text = ""; overlay.invalidate() }
                    return@execute
                }
                if (d.pieces.all { it == null }) return@execute
                solvedSig = sig
                val pcs = d.pieces.mapIndexedNotNull { i, p -> if (p != null && p.shape >= 0) Pair(i, p.shape) else null }
                val bad = d.pieces.any { it != null && it.shape < 0 }
                val mv = Solver.solve(d.rows, pcs)
                h.post {
                    overlay.moves = mv; overlay.boxes = d.pieces.map { it?.box }
                    overlay.text = if (bad) "Ada bidak tidak terbaca" else if (mv.isEmpty()) "Tidak ada langkah" else ""
                    overlay.invalidate()
                }
            } finally { busy.set(false) }
        }
    }

    override fun onDestroy() {
        h.removeCallbacks(loop)
        synchronized(lock) { held?.close(); held = null }
        exec.shutdownNow()
        runCatching { wm.removeView(overlay); wm.removeView(bar) }
        proj?.stop()
        super.onDestroy()
    }
}
