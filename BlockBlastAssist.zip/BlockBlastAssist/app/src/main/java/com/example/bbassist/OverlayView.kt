package com.example.bbassist

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

class OverlayView(ctx: Context) : View(ctx) {
    var moves: List<Move> = emptyList()
    var boxes: List<RectF?> = emptyList()
    var cal: FloatArray? = null
    var text = ""
    var showRects = false
    private var calibrating = false
    private var onCal: ((FloatArray) -> Unit)? = null
    private val taps = ArrayList<PointF>()
    private val colors = intArrayOf(0xFFFFEBD7.toInt(), 0xFFD7FFEB.toInt(), 0xFFD7EBFF.toInt())
    private val prompts = listOf(
        "Ketuk pojok KIRI-ATAS papan 8x8", "Ketuk pojok KANAN-BAWAH papan 8x8",
        "Ketuk pojok KIRI-ATAS area 3 bidak", "Ketuk pojok KANAN-BAWAH area 3 bidak"
    )
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun startCal(cb: (FloatArray) -> Unit) {
        calibrating = true; onCal = cb; taps.clear(); showRects = false; moves = emptyList()
        text = prompts[0]; invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!calibrating) return false
        if (e.action == MotionEvent.ACTION_DOWN) {
            taps.add(PointF(e.x / width, e.y / height))
            if (taps.size == 4) {
                val c = FloatArray(8) { if (it % 2 == 0) taps[it / 2].x else taps[it / 2].y }
                taps.clear(); calibrating = false; cal = c; showRects = true
                text = "Kalibrasi tersimpan. Cek kotak, lalu tekan Scan."
                onCal?.invoke(c)
            } else text = prompts[taps.size]
            invalidate()
        }
        return true
    }

    private fun label(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Int) {
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.textSize = size
        p.color = col; p.setShadowLayer(8f, 0f, 0f, Color.BLACK)
        c.drawText(s, x, y, p); p.clearShadowLayer()
    }

    override fun onDraw(c: Canvas) {
        val g = cal
        if (g != null) {
            val bx = g[0] * width; val by = g[1] * height
            val cw = (g[2] * width - bx) / 8; val ch = (g[3] * height - by) / 8
            if (showRects) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = Color.WHITE
                c.drawRect(bx, by, g[2] * width, g[3] * height, p)
                c.drawRect(g[4] * width, g[5] * height, g[6] * width, g[7] * height, p)
            }
            moves.forEachIndexed { i, m ->
                val s = Solver.shapes[m.shape]
                p.style = Paint.Style.FILL; p.color = colors[i % 3]; p.alpha = 150
                for (r in 0 until s.h) for (q in 0 until s.w) if (s.rows[r][q] == '#') {
                    val l = bx + (m.c + q) * cw; val t = by + (m.r + r) * ch
                    c.drawRoundRect(l + 3, t + 3, l + cw - 3, t + ch - 3, 12f, 12f, p)
                }
                label(c, "${i + 1}", bx + (m.c + s.w / 2f) * cw, by + (m.r + s.h / 2f) * ch + cw * .25f, cw * .7f, Color.WHITE)
                boxes.getOrNull(m.slot)?.let {
                    label(c, "${i + 1}", (it.left + it.right) / 2 * width, it.top * height - 16f, cw * .7f, colors[i % 3])
                }
            }
        }
        p.style = Paint.Style.FILL; p.color = Color.WHITE; p.textAlign = Paint.Align.LEFT; p.textSize = 38f
        p.setShadowLayer(8f, 0f, 0f, Color.BLACK); c.drawText(text, 24f, 150f, p); p.clearShadowLayer()
        p.color = Color.YELLOW
        for (t in taps) c.drawCircle(t.x * width, t.y * height, 14f, p)
    }
}
