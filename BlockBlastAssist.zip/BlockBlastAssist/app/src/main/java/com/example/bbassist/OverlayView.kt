package com.example.bbassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

class OverlayView(ctx: Context) : View(ctx) {
    var moves: List<Move> = emptyList()
    var boxes: List<RectF?> = emptyList()
    var board: FloatArray? = null   // x0, y0, x1, y1 as screen fractions
    var text = ""
    // Pastel tints: low saturation, so the detector never mistakes them for blocks.
    private val tint = intArrayOf(0xFFFFEBD7.toInt(), 0xFFD7FFEB.toInt(), 0xFFD7EBFF.toInt())
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun label(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Int) {
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.textSize = size
        p.color = col; p.setShadowLayer(8f, 0f, 0f, Color.BLACK)
        c.drawText(s, x, y, p); p.clearShadowLayer()
    }

    override fun onDraw(c: Canvas) {
        val g = board
        if (g != null) {
            val bx = g[0] * width; val by = g[1] * height
            val cw = (g[2] - g[0]) * width / 8f; val ch = (g[3] - g[1]) * height / 8f
            moves.forEachIndexed { i, m ->
                val s = Solver.shapes[m.shape]
                val col = tint[i % 3]
                for (r in 0 until s.h) for (q in 0 until s.w) if (s.rows[r][q] == '#') {
                    val l = bx + (m.c + q) * cw; val t = by + (m.r + r) * ch
                    p.style = Paint.Style.FILL; p.color = col; p.alpha = 38
                    c.drawRoundRect(l + 3, t + 3, l + cw - 3, t + ch - 3, 12f, 12f, p)
                    p.style = Paint.Style.STROKE; p.strokeWidth = 6f; p.color = col
                    c.drawRoundRect(l + 6, t + 6, l + cw - 6, t + ch - 6, 12f, 12f, p)
                }
                label(c, "${i + 1}", bx + (m.c + s.w / 2f) * cw, by + (m.r + s.h / 2f) * ch + cw * .25f, cw * .7f, col)
                boxes.getOrNull(m.slot)?.let {
                    label(c, "${i + 1}", (it.left + it.right) / 2f * width, it.top * height - 16f, cw * .7f, col)
                }
            }
        }
        if (text.isNotEmpty()) {
            p.style = Paint.Style.FILL; p.color = Color.WHITE; p.textAlign = Paint.Align.LEFT; p.textSize = 38f
            p.setShadowLayer(8f, 0f, 0f, Color.BLACK); c.drawText(text, 24f, 150f, p); p.clearShadowLayer()
        }
    }
}
