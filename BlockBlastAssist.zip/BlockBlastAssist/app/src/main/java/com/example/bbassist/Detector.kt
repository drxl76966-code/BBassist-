package com.example.bbassist

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF

class Piece(val shape: Int, val box: RectF) // box in screen fractions
class Parsed(val rows: IntArray, val pieces: List<Piece?>)

object Detector {
    /** A pixel counts as a block if its brightest channel exceeds this (empty cells are dark navy). */
    const val THR = 150
    /** Blocks are saturated colours; the pastel overlay we draw is below this, so it never pollutes detection. */
    const val SAT = 55

    private fun on(b: Bitmap, x: Int, y: Int): Boolean {
        val p = b.getPixel(x.coerceIn(0, b.width - 1), y.coerceIn(0, b.height - 1))
        val mx = maxOf(Color.red(p), Color.green(p), Color.blue(p)); val mn = minOf(Color.red(p), Color.green(p), Color.blue(p))
        return mx > THR && mx - mn > SAT
    }
    private fun filled(b: Bitmap, cx: Float, cy: Float, rad: Float): Boolean {
        var n = 0
        for ((dx, dy) in listOf(0 to 0, -1 to -1, 1 to -1, -1 to 1, 1 to 1))
            if (on(b, (cx + dx * rad).toInt(), (cy + dy * rad).toInt())) n++
        return n >= 3
    }

    /** c = board x0,y0,x1,y1 then tray x0,y0,x1,y1 (screen fractions). ratio = tray cell size / board cell size. */
    fun parse(b: Bitmap, c: FloatArray, ratio: Float): Parsed {
        val w = b.width.toFloat(); val h = b.height.toFloat()
        val bx = c[0] * w; val by = c[1] * h
        val cw = (c[2] * w - bx) / 8; val ch = (c[3] * h - by) / 8
        val rows = IntArray(8)
        for (r in 0..7) for (q in 0..7)
            if (filled(b, bx + (q + .5f) * cw, by + (r + .5f) * ch, cw * .25f)) rows[r] = rows[r] or (1 shl q)
        val tx = c[4] * w; val ty = c[5] * h
        val tw = (c[6] * w - tx) / 3; val th = c[7] * h - ty
        return Parsed(rows, (0..2).map { piece(b, tx + it * tw, ty, tw, th, cw * ratio) })
    }

    private fun piece(b: Bitmap, x0: Float, y0: Float, w: Float, h: Float, s: Float): Piece? {
        var minX = 1e9f; var maxX = -1f; var minY = 1e9f; var maxY = -1f
        var y = y0
        while (y < y0 + h) {
            var x = x0
            while (x < x0 + w) {
                if (on(b, x.toInt(), y.toInt())) { minX = minOf(minX, x); maxX = maxOf(maxX, x); minY = minOf(minY, y); maxY = maxOf(maxY, y) }
                x += 4f
            }
            y += 4f
        }
        if (maxX < 0) return null
        val bw = maxX - minX + 4f; val bh = maxY - minY + 4f
        val cols = Math.round(bw / s).coerceIn(1, 5); val rws = Math.round(bh / s).coerceIn(1, 5)
        val uw = bw / cols; val uh = bh / rws
        val rows = (0 until rws).map { r ->
            (0 until cols).joinToString("") { q -> if (filled(b, minX + (q + .5f) * uw, minY + (r + .5f) * uh, minOf(uw, uh) * .2f)) "#" else "." }
        }
        val idx = Solver.indexOf(rows)
        if (idx < 0) return null
        return Piece(idx, RectF(minX / b.width, minY / b.height, maxX / b.width, maxY / b.height))
    }
}
