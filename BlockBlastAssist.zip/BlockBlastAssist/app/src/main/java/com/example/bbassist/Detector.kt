package com.example.bbassist

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF

/** shape = -1 means "a piece is there but its shape is not recognised". box = screen fractions. */
class Piece(val shape: Int, val box: RectF)
class Parsed(val rows: IntArray, val pieces: List<Piece?>)
/** Board square as fractions of the screen. */
class BoardRect(val fx0: Float, val fy0: Float, val fx1: Float, val fy1: Float)

object Detector {
    const val THR = 150
    const val SAT = 55
    /** Tray cell size / board cell size (game constant, ~0.445). Others are fallbacks. */
    private val RATIOS = floatArrayOf(0.445f, 0.43f, 0.46f, 0.41f, 0.48f, 0.5f, 0.38f)

    private fun px(b: Bitmap, x: Int, y: Int): Int = b.getPixel(x.coerceIn(0, b.width - 1), y.coerceIn(0, b.height - 1))

    /** A block: bright AND saturated (our own pastel overlay never matches). */
    private fun bright(p: Int): Boolean {
        val r = Color.red(p); val g = Color.green(p); val bl = Color.blue(p)
        val mx = maxOf(r, g, bl); val mn = minOf(r, g, bl)
        return mx > THR && mx - mn > SAT
    }

    /** Empty board cell: dark navy. */
    private fun navy(p: Int): Boolean {
        val r = Color.red(p); val g = Color.green(p); val bl = Color.blue(p)
        return maxOf(r, g, bl) < 135 && bl > r + 20 && bl >= g
    }

    private fun filled(b: Bitmap, cx: Float, cy: Float, rad: Float): Boolean {
        var n = 0
        for ((dx, dy) in listOf(0 to 0, -1 to -1, 1 to -1, -1 to 1, 1 to 1))
            if (bright(px(b, (cx + dx * rad).toInt(), (cy + dy * rad).toInt()))) n++
        return n >= 3
    }

    /** Finds the 8x8 board automatically: width from the dark navy columns, then the vertical spot with the most navy. */
    fun findBoard(b: Bitmap): BoardRect? {
        val w = b.width; val h = b.height
        var left = -1; var right = -1
        var x = 0
        while (x < w) {
            var n = 0; var y = 0
            while (y < h) { if (navy(px(b, x, y))) n++; y += 8 }
            if (n >= 24) { if (left < 0) left = x; right = x }
            x += 4
        }
        if (left < 0) return null
        val size = right - left
        if (size < 0.55f * w) return null
        val len = size / 4
        val rowN = IntArray(h / 4 + 1)
        var yy = 0
        while (yy < h) {
            var n = 0; var xx = left
            while (xx <= right) { if (navy(px(b, xx, yy))) n++; xx += 8 }
            rowN[yy / 4] = n
            yy += 4
        }
        if (len >= rowN.size) return null
        var cur = 0
        for (i in 0 until len) cur += rowN[i]
        var best = cur; var bestStart = 0
        for (st in 1 until rowN.size - len) {
            cur += rowN[st + len - 1] - rowN[st - 1]
            if (cur > best) { best = cur; bestStart = st }
        }
        if (best < 0.2f * len * (size / 8 + 1)) return null
        val y0 = bestStart * 4
        return BoardRect(left.toFloat() / w, y0.toFloat() / h, (left + size).toFloat() / w, (y0 + size).toFloat() / h)
    }

    /** True if every board cell centre is either an empty (navy) cell or a coloured block. */
    fun looksLikeBoard(b: Bitmap, r: BoardRect): Boolean {
        val w = b.width.toFloat(); val h = b.height.toFloat()
        val cw = (r.fx1 - r.fx0) * w / 8f; val ch = (r.fy1 - r.fy0) * h / 8f
        var known = 0
        for (i in 0..7) for (j in 0..7) {
            val p = px(b, (r.fx0 * w + (j + .5f) * cw).toInt(), (r.fy0 * h + (i + .5f) * ch).toInt())
            if (navy(p) || bright(p)) known++
        }
        return known >= 52
    }

    fun parse(b: Bitmap, r: BoardRect): Parsed {
        val w = b.width.toFloat(); val h = b.height.toFloat()
        val bx = r.fx0 * w; val by = r.fy0 * h
        val cw = (r.fx1 - r.fx0) * w / 8f; val ch = (r.fy1 - r.fy0) * h / 8f
        val rows = IntArray(8)
        for (i in 0..7) for (j in 0..7)
            if (filled(b, bx + (j + .5f) * cw, by + (i + .5f) * ch, cw * .25f)) rows[i] = rows[i] or (1 shl j)
        // Tray: below the board, split into three equal columns.
        val bwPx = cw * 8f
        val ty0 = by + ch * 8f + 0.06f * bwPx
        val th = 0.49f * bwPx
        val tw = bwPx / 3f
        var best: List<Piece?> = listOf(null, null, null)
        var bestN = -1
        for (ratio in RATIOS) {
            val pcs = (0..2).map { piece(b, bx + it * tw, ty0, tw, th, cw * ratio) }
            val n = pcs.count { it != null && it.shape >= 0 }
            if (n > bestN) { bestN = n; best = pcs }
        }
        return Parsed(rows, best)
    }

    private fun piece(b: Bitmap, x0: Float, y0: Float, w: Float, h: Float, s: Float): Piece? {
        var minX = 1e9f; var maxX = -1f; var minY = 1e9f; var maxY = -1f
        var y = y0
        while (y < y0 + h) {
            var x = x0
            while (x < x0 + w) {
                if (bright(px(b, x.toInt(), y.toInt()))) { minX = minOf(minX, x); maxX = maxOf(maxX, x); minY = minOf(minY, y); maxY = maxOf(maxY, y) }
                x += 4f
            }
            y += 4f
        }
        if (maxX < 0) return null
        val box = RectF(minX / b.width, minY / b.height, maxX / b.width, maxY / b.height)
        val bw = maxX - minX + 4f; val bh = maxY - minY + 4f
        val cols = Math.round(bw / s).coerceIn(1, 5); val rws = Math.round(bh / s).coerceIn(1, 5)
        val uw = bw / cols; val uh = bh / rws
        val rows = (0 until rws).map { r ->
            (0 until cols).joinToString("") { q -> if (filled(b, minX + (q + .5f) * uw, minY + (r + .5f) * uh, minOf(uw, uh) * .2f)) "#" else "." }
        }
        return Piece(Solver.indexOf(rows), box)
    }
}
