# Block Blast Assist

Android overlay assistant for Block Blast (screen capture -> solver -> on-screen hints).

APK is built by GitHub Actions: Actions tab -> "Build APK" -> latest run -> Artifacts.
Push a tag like `v1.0` to also get the APK attached to a GitHub Release.
